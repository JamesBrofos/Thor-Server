# Thor MATLAB Client

This repository contains the Thor MATLAB Client, which is a client-side interface for Thor Server. The Thor Server and Thor MATLAB Client together provide a light-weight and powerful architecture for Bayesian optimization in MATLAB.

## Installation

1. Clone this repository. `git clone git@github.com:JamesBrofos/Thor-MATLAB-Client.git`
2. TODO
3. Make sure you have signed up for an account with Thor by visiting Thor's website: [Thor](http://127.0.0.1:5000/)
